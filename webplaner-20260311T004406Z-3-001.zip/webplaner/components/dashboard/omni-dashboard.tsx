"use client";

import { AnimatePresence, motion } from "framer-motion";
import {
  ArrowUpRight,
  AudioLines,
  Bot,
  BrainCircuit,
  CalendarCheck2,
  Clock3,
  Command,
  Mic,
  NotepadText,
  PhoneCall,
  Presentation,
  Send,
  Slack,
  Sparkles,
  Workflow
} from "lucide-react";
import { startTransition, useDeferredValue, useMemo, useState } from "react";

import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";

type Integration = {
  name: string;
  status: "Connected" | "Ready" | "Awaiting Auth";
  description: string;
  icon: typeof Presentation;
  accent: string;
  action: string;
};

type PipelineStatus = "running" | "queued" | "completed";

type PipelineItem = {
  id: string;
  title: string;
  detail: string;
  status: PipelineStatus;
  eta: string;
};

type CommandPreview = {
  id: string;
  text: string;
  createdAt: string;
};

const integrations: Integration[] = [
  {
    name: "Google Slides",
    status: "Connected",
    description: "Generate deck drafts, route approvals, and publish polished client updates.",
    icon: Presentation,
    accent: "from-orange-300/80 to-rose-400/70",
    action: "Create draft"
  },
  {
    name: "Slack",
    status: "Connected",
    description: "Dispatch follow-ups, summarize channels, and keep stakeholders synced in real time.",
    icon: Slack,
    accent: "from-sky-300/80 to-cyan-400/70",
    action: "Send update"
  },
  {
    name: "Notion",
    status: "Ready",
    description: "Capture specs, action items, and research traces inside your operating knowledge base.",
    icon: NotepadText,
    accent: "from-fuchsia-300/80 to-violet-500/70",
    action: "Write brief"
  }
];

const initialPipeline: PipelineItem[] = [
  {
    id: "task-1",
    title: "Prepare caterer outreach",
    detail: "Analyzing vendor notes, recent messages, and preferred call windows.",
    status: "running",
    eta: "Live now"
  },
  {
    id: "task-2",
    title: "Draft board-deck status page",
    detail: "Bundling KPIs and slide-ready narrative for Google Slides export.",
    status: "queued",
    eta: "2 min"
  },
  {
    id: "task-3",
    title: "Sync Notion action log",
    detail: "Publishing completed actions, decision notes, and owner follow-ups.",
    status: "completed",
    eta: "Just now"
  }
];

const quickCommands = [
  "Call the caterer and confirm the guest count",
  "Draft a Slack update for the product launch war room",
  "Create a Notion brief from today's action pipeline"
];

const commandSuggestions = [
  "call vendor",
  "send slack update",
  "draft notion brief",
  "build slide deck",
  "summarize pipeline"
];

const metricCards = [
  {
    label: "Autonomous Actions",
    value: "128",
    change: "+18 today",
    icon: Bot
  },
  {
    label: "Voice Profiles",
    value: "04",
    change: "1 pending clone",
    icon: AudioLines
  },
  {
    label: "Connected Apps",
    value: "09",
    change: "Slack, Notion, Google live",
    icon: BrainCircuit
  }
];

const surfaceMotion = {
  initial: { opacity: 0, y: 24, scale: 0.98 },
  animate: { opacity: 1, y: 0, scale: 1 },
  transition: { duration: 0.48, ease: [0.22, 1, 0.36, 1] as const }
};

function getStatusClasses(status: PipelineStatus) {
  switch (status) {
    case "running":
      return "task-active-border bg-white/7";
    case "completed":
      return "border border-emerald-400/18 bg-emerald-400/8";
    default:
      return "border border-white/10 bg-white/4";
  }
}

function getStatusLabel(status: PipelineStatus) {
  switch (status) {
    case "running":
      return "Running";
    case "completed":
      return "Completed";
    default:
      return "Queued";
  }
}

export function OmniDashboard() {
  const [command, setCommand] = useState("");
  const [commandPreviews, setCommandPreviews] = useState<CommandPreview[]>([]);
  const deferredCommand = useDeferredValue(command.trim().toLowerCase());

  const filteredSuggestions = useMemo(() => {
    if (!deferredCommand) {
      return quickCommands;
    }

    return quickCommands.filter((item) => item.toLowerCase().includes(deferredCommand));
  }, [deferredCommand]);

  function queuePreview(nextCommand: string) {
    const normalized = nextCommand.trim();

    if (!normalized) {
      return;
    }

    startTransition(() => {
      setCommandPreviews((current) => [
        {
          id: `${Date.now()}-${normalized}`,
          text: normalized,
          createdAt: "Queued locally"
        },
        ...current
      ].slice(0, 4));
      setCommand("");
    });
  }

  return (
    <>
      <section className="grid grid-cols-1 gap-6 lg:grid-cols-12">
        <motion.section
          {...surfaceMotion}
          className="glass-panel relative col-span-full overflow-hidden p-7 sm:p-8 lg:col-span-7 xl:p-10"
        >
          <div className="pointer-events-none absolute inset-y-0 right-0 w-1/2 bg-[radial-gradient(circle_at_top_right,rgba(34,211,238,0.16),transparent_42%)]" />
          <div className="relative flex flex-col gap-8">
            <div className="flex flex-wrap items-start justify-between gap-5">
              <div className="max-w-3xl">
                <div className="inline-flex items-center gap-2 rounded-full border border-white/12 bg-white/7 px-4 py-2 text-xs uppercase tracking-[0.28em] text-accent-cyan">
                  <Sparkles className="h-3.5 w-3.5" />
                  Omni Command Layer
                </div>
                <h1 className="mt-5 max-w-3xl font-display text-4xl font-semibold leading-tight text-white sm:text-5xl xl:text-[3.7rem] xl:leading-[1.02]">
                  Delegate messy, multi-app work like you already hired your{" "}
                  <span className="text-gradient-accent">AI chief of staff.</span>
                </h1>
                <p className="mt-4 max-w-2xl text-base leading-7 text-slate-300/88 sm:text-lg">
                  WebPlan turns natural-language commands into phone calls, workspace updates,
                  document actions, and background pipelines with a tactile control surface.
                </p>
              </div>

              <motion.div
                whileHover={{ y: -3, scale: 1.01 }}
                transition={{ type: "spring", stiffness: 220, damping: 20 }}
                className="glass-subtle min-w-[16rem] rounded-[30px] p-4"
              >
                <div className="flex items-center gap-3">
                  <div className="flex h-11 w-11 items-center justify-center rounded-[18px] bg-white/8 text-accent-violet">
                    <PhoneCall className="h-5 w-5" />
                  </div>
                  <div>
                    <p className="text-xs uppercase tracking-[0.24em] text-slate-400">
                      Human Proxy
                    </p>
                    <p className="text-sm font-medium text-white">Outbound call window open</p>
                  </div>
                </div>
                <p className="mt-4 text-sm leading-6 text-slate-300/84">
                  Voice agents can step in for scheduling, confirmations, and status collection.
                </p>
              </motion.div>
            </div>

            <div className="grid gap-4 md:grid-cols-3">
              {metricCards.map(({ label, value, change, icon: Icon }, index) => (
                <motion.article
                  key={label}
                  initial={{ opacity: 0, y: 18 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.08 * index, duration: 0.4 }}
                  whileHover={{ y: -4, scale: 1.01 }}
                  className="glass-subtle rounded-[28px] p-4"
                >
                  <div className="flex items-center justify-between gap-4">
                    <div>
                      <p className="text-xs uppercase tracking-[0.24em] text-slate-400">{label}</p>
                      <p className="mt-3 font-display text-3xl font-semibold text-white">{value}</p>
                    </div>
                    <div className="flex h-11 w-11 items-center justify-center rounded-[18px] bg-white/8 text-accent-cyan">
                      <Icon className="h-5 w-5" />
                    </div>
                  </div>
                  <p className="mt-4 text-sm text-slate-300/82">{change}</p>
                </motion.article>
              ))}
            </div>
          </div>
        </motion.section>

        <motion.section
          {...surfaceMotion}
          transition={{ ...surfaceMotion.transition, delay: 0.08 }}
          className="glass-panel col-span-full p-6 lg:col-span-5"
        >
          <div className="flex items-start justify-between gap-4">
            <div>
              <p className="text-xs uppercase tracking-[0.24em] text-slate-400">Voice Lab</p>
              <h2 className="mt-2 font-display text-2xl font-semibold text-white">Clone, route, call</h2>
              <p className="mt-3 max-w-md text-sm leading-6 text-slate-300/84">
                The shell is in place for cloned voices, call launches, and real-time agent orchestration.
              </p>
            </div>
            <div className="flex h-12 w-12 items-center justify-center rounded-[20px] bg-white/8 text-accent-violet">
              <Mic className="h-5 w-5" />
            </div>
          </div>

          <div className="mt-6 grid gap-4 md:grid-cols-2">
            <motion.div whileHover={{ y: -3 }} className="glass-subtle rounded-[28px] p-4">
              <div className="flex items-center gap-3">
                <div className="rounded-[16px] bg-white/8 p-3 text-accent-cyan">
                  <AudioLines className="h-4 w-4" />
                </div>
                <div>
                  <p className="text-sm font-medium text-white">Clone Voice</p>
                  <p className="text-xs text-slate-400">Mic capture and upload in Step 4</p>
                </div>
              </div>
              <Button variant="glass" size="sm" className="mt-5 w-full justify-between" disabled>
                Voice capture shell ready
                <ArrowUpRight className="h-4 w-4" />
              </Button>
            </motion.div>

            <motion.div whileHover={{ y: -3 }} className="glass-subtle rounded-[28px] p-4">
              <div className="flex items-center gap-3">
                <div className="rounded-[16px] bg-white/8 p-3 text-accent-violet">
                  <PhoneCall className="h-4 w-4" />
                </div>
                <div>
                  <p className="text-sm font-medium text-white">Make Agent Call</p>
                  <p className="text-xs text-slate-400">Vapi relay wiring arrives in Step 5</p>
                </div>
              </div>
              <Button variant="glass" size="sm" className="mt-5 w-full justify-between" disabled>
                Telephony shell ready
                <ArrowUpRight className="h-4 w-4" />
              </Button>
            </motion.div>
          </div>
        </motion.section>

        <motion.section
          {...surfaceMotion}
          transition={{ ...surfaceMotion.transition, delay: 0.12 }}
          className="glass-panel col-span-full p-6 lg:col-span-7"
        >
          <div className="flex flex-wrap items-center justify-between gap-4">
            <div>
              <p className="text-xs uppercase tracking-[0.24em] text-slate-400">Integrations Hub</p>
              <h2 className="mt-2 font-display text-2xl font-semibold text-white">
                Connected apps, one control plane
              </h2>
            </div>
            <div className="inline-flex items-center gap-2 rounded-full border border-white/10 bg-white/6 px-4 py-2 text-xs uppercase tracking-[0.24em] text-slate-300">
              3 live adapters
            </div>
          </div>

          <div className="mt-6 grid gap-4 md:grid-cols-3">
            {integrations.map(({ name, status, description, icon: Icon, accent, action }, index) => (
              <motion.article
                key={name}
                initial={{ opacity: 0, y: 16 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.1 * index, duration: 0.4 }}
                whileHover={{ y: -5 }}
                className="glass-subtle rounded-[30px] p-4"
              >
                <div className="flex items-start justify-between gap-4">
                  <div
                    className={cn(
                      "flex h-12 w-12 items-center justify-center rounded-[18px] bg-gradient-to-br text-slate-950 shadow-[0_16px_36px_rgba(15,23,42,0.24)]",
                      accent
                    )}
                  >
                    <Icon className="h-5 w-5" />
                  </div>
                  <span className="rounded-full border border-white/10 bg-white/6 px-3 py-1 text-[11px] uppercase tracking-[0.2em] text-slate-300">
                    {status}
                  </span>
                </div>
                <h3 className="mt-5 font-display text-xl font-semibold text-white">{name}</h3>
                <p className="mt-3 min-h-24 text-sm leading-6 text-slate-300/82">{description}</p>
                <Button variant="glass" size="sm" className="mt-5 w-full justify-between">
                  {action}
                  <ArrowUpRight className="h-4 w-4" />
                </Button>
              </motion.article>
            ))}
          </div>
        </motion.section>

        <motion.section
          {...surfaceMotion}
          transition={{ ...surfaceMotion.transition, delay: 0.16 }}
          className="glass-panel col-span-full p-6 lg:col-span-5"
        >
          <div className="flex flex-wrap items-start justify-between gap-4">
            <div>
              <p className="text-xs uppercase tracking-[0.24em] text-slate-400">Action Pipeline</p>
              <h2 className="mt-2 font-display text-2xl font-semibold text-white">
                Background work you can actually follow
              </h2>
            </div>
            <div className="inline-flex items-center gap-2 rounded-full border border-cyan-400/15 bg-cyan-400/8 px-3 py-1.5 text-xs text-cyan-200">
              <span className="status-ping h-2.5 w-2.5 rounded-full bg-cyan-300" />
              Live surface
            </div>
          </div>

          <div className="mt-6 space-y-4">
            {initialPipeline.map((item, index) => (
              <motion.article
                key={item.id}
                initial={{ opacity: 0, x: 14 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: 0.08 * index, duration: 0.36 }}
                className={cn("rounded-[28px] p-4", getStatusClasses(item.status))}
              >
                <div className="flex gap-4">
                  <div className="flex w-10 flex-col items-center pt-1">
                    <div
                      className={cn(
                        "flex h-10 w-10 items-center justify-center rounded-[16px] border",
                        item.status === "running"
                          ? "border-cyan-300/25 bg-cyan-300/10 text-cyan-200"
                          : item.status === "completed"
                            ? "border-emerald-300/25 bg-emerald-300/10 text-emerald-200"
                            : "border-white/12 bg-white/7 text-slate-200"
                      )}
                    >
                      {item.status === "running" ? (
                        <Workflow className="h-4 w-4" />
                      ) : item.status === "completed" ? (
                        <CalendarCheck2 className="h-4 w-4" />
                      ) : (
                        <Clock3 className="h-4 w-4" />
                      )}
                    </div>
                    {index < initialPipeline.length - 1 ? (
                      <div className="mt-2 h-full min-h-10 w-px bg-gradient-to-b from-white/18 to-transparent" />
                    ) : null}
                  </div>

                  <div className="flex-1">
                    <div className="flex flex-wrap items-start justify-between gap-3">
                      <div>
                        <h3 className="text-base font-semibold text-white">{item.title}</h3>
                        <p className="mt-2 text-sm leading-6 text-slate-300/84">{item.detail}</p>
                      </div>
                      <div className="text-right">
                        <p className="text-xs uppercase tracking-[0.22em] text-slate-400">
                          {getStatusLabel(item.status)}
                        </p>
                        <p className="mt-2 text-sm text-slate-200">{item.eta}</p>
                      </div>
                    </div>
                  </div>
                </div>
              </motion.article>
            ))}
          </div>
        </motion.section>

        <motion.section
          {...surfaceMotion}
          transition={{ ...surfaceMotion.transition, delay: 0.18 }}
          className="glass-panel col-span-full p-6 xl:col-span-4"
        >
          <div className="flex items-center justify-between gap-4">
            <div>
              <p className="text-xs uppercase tracking-[0.24em] text-slate-400">Preview Queue</p>
              <h2 className="mt-2 font-display text-2xl font-semibold text-white">
                Commands staged from the composer
              </h2>
            </div>
            <div className="flex h-12 w-12 items-center justify-center rounded-[18px] bg-white/8 text-accent-cyan">
              <Command className="h-5 w-5" />
            </div>
          </div>

          <div className="mt-6 min-h-[16rem] space-y-3">
            <AnimatePresence initial={false}>
              {commandPreviews.length > 0 ? (
                commandPreviews.map((item) => (
                  <motion.div
                    key={item.id}
                    layout
                    initial={{ opacity: 0, y: 12 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: -10 }}
                    className="glass-subtle rounded-[24px] px-4 py-3"
                  >
                    <p className="text-sm font-medium text-white">{item.text}</p>
                    <p className="mt-2 text-xs uppercase tracking-[0.2em] text-slate-400">
                      {item.createdAt}
                    </p>
                  </motion.div>
                ))
              ) : (
                <motion.div
                  initial={{ opacity: 0, y: 12 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="glass-subtle flex min-h-[16rem] items-center justify-center rounded-[28px] p-6 text-center"
                >
                  <div>
                    <p className="font-display text-xl font-semibold text-white">No staged commands yet</p>
                    <p className="mt-3 text-sm leading-6 text-slate-300/82">
                      Use the floating composer below to queue a preview command before the API relay lands in Step 5.
                    </p>
                  </div>
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        </motion.section>

        <motion.section
          {...surfaceMotion}
          transition={{ ...surfaceMotion.transition, delay: 0.22 }}
          className="glass-panel col-span-full p-6 xl:col-span-8"
        >
          <div className="flex flex-wrap items-start justify-between gap-4">
            <div>
              <p className="text-xs uppercase tracking-[0.24em] text-slate-400">Suggested Automations</p>
              <h2 className="mt-2 font-display text-2xl font-semibold text-white">
                High-leverage moves for the command layer
              </h2>
            </div>
            <Button variant="glass" size="sm">
              Explore templates
            </Button>
          </div>

          <div className="mt-6 grid gap-4 md:grid-cols-3">
            {[
              {
                title: "Vendor Call Sprint",
                description: "Dial through suppliers, capture confirmations, and publish updates to Slack.",
                icon: PhoneCall
              },
              {
                title: "Board Brief Assembly",
                description: "Compile metrics, shape the narrative, and draft a Google Slides deck.",
                icon: Presentation
              },
              {
                title: "Ops Memory Sync",
                description: "Convert live actions into a structured Notion operating log.",
                icon: NotepadText
              }
            ].map(({ title, description, icon: Icon }) => (
              <motion.article
                key={title}
                whileHover={{ y: -4 }}
                className="rounded-[28px] border border-white/10 bg-[linear-gradient(180deg,rgba(255,255,255,0.08),rgba(255,255,255,0.03))] p-4"
              >
                <div className="flex h-11 w-11 items-center justify-center rounded-[18px] bg-white/8 text-accent-violet">
                  <Icon className="h-5 w-5" />
                </div>
                <h3 className="mt-5 font-display text-xl font-semibold text-white">{title}</h3>
                <p className="mt-3 text-sm leading-6 text-slate-300/82">{description}</p>
              </motion.article>
            ))}
          </div>
        </motion.section>
      </section>

      <div className="pointer-events-none fixed inset-x-0 bottom-0 z-40 h-36 bg-gradient-to-t from-[#020617] via-[#020617]/80 to-transparent" />

      <motion.div
        initial={{ opacity: 0, y: 40 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.26, duration: 0.46, ease: [0.22, 1, 0.36, 1] }}
        className="fixed inset-x-0 bottom-5 z-50 px-4 sm:px-6 lg:px-10"
      >
        <div className="mx-auto max-w-[1120px]">
          <div className="command-center glass-panel border-white/14 px-4 py-4 shadow-[0_24px_80px_rgba(2,6,23,0.62)] sm:px-5">
            <form
              onSubmit={(event) => {
                event.preventDefault();
                queuePreview(command);
              }}
            >
              <div className="flex flex-col gap-4 lg:flex-row lg:items-end">
                <div className="flex-1">
                  <label
                    htmlFor="omni-command"
                    className="text-[11px] uppercase tracking-[0.26em] text-slate-400"
                  >
                    Omni-Command Center
                  </label>
                  <div className="mt-3 flex items-center gap-3 rounded-[28px] border border-white/10 bg-slate-950/45 px-4 py-3 shadow-[inset_0_1px_0_rgba(255,255,255,0.03)]">
                    <div className="flex h-10 w-10 items-center justify-center rounded-[18px] bg-white/7 text-accent-cyan">
                      <Command className="h-4 w-4" />
                    </div>
                    <input
                      id="omni-command"
                      value={command}
                      onChange={(event) => {
                        setCommand(event.target.value);
                      }}
                      placeholder="Type a natural language command, like “Call the caterer and confirm delivery.”"
                      className="h-10 flex-1 bg-transparent text-sm text-white outline-none placeholder:text-slate-500"
                    />
                    <Button type="submit" className="hidden lg:inline-flex" disabled={!command.trim()}>
                      Relay
                      <Send className="h-4 w-4" />
                    </Button>
                  </div>
                </div>

                <div className="flex gap-3 lg:hidden">
                  <Button type="submit" className="w-full" disabled={!command.trim()}>
                    Relay
                    <Send className="h-4 w-4" />
                  </Button>
                </div>
              </div>
            </form>

            <div className="mt-4 flex flex-col gap-3 lg:flex-row lg:items-center lg:justify-between">
              <div className="flex flex-wrap gap-2">
                {(filteredSuggestions.length > 0 ? filteredSuggestions : commandSuggestions).map((item) => (
                  <button
                    key={item}
                    type="button"
                    onClick={() => {
                      queuePreview(item);
                    }}
                    className="squishy-button rounded-full border border-white/10 bg-white/6 px-3 py-2 text-xs text-slate-200 hover:bg-white/10"
                  >
                    {item}
                  </button>
                ))}
              </div>

              <p className="text-xs uppercase tracking-[0.22em] text-slate-500">
                Local preview mode until <span className="text-slate-300">/api/command</span> lands in Step 5
              </p>
            </div>
          </div>
        </div>
      </motion.div>
    </>
  );
}
