import * as React from "react";
import { Slot } from "@radix-ui/react-slot";
import { cva, type VariantProps } from "class-variance-authority";

import { cn } from "@/lib/utils";

const buttonVariants = cva(
  "squishy-button inline-flex items-center justify-center gap-2 whitespace-nowrap rounded-[20px] text-sm font-semibold tracking-[0.01em] transition-all outline-none focus-visible:ring-2 focus-visible:ring-accent-cyan/80 focus-visible:ring-offset-2 focus-visible:ring-offset-background disabled:pointer-events-none disabled:opacity-50",
  {
    variants: {
      variant: {
        default:
          "bg-[linear-gradient(135deg,rgba(139,92,246,0.98),rgba(34,211,238,0.88))] text-slate-950 shadow-[0_16px_40px_rgba(34,211,238,0.18)] hover:brightness-110",
        glass:
          "border border-white/12 bg-white/6 text-slate-100 backdrop-blur-xl hover:bg-white/10",
        ghost: "text-slate-200 hover:bg-white/8"
      },
      size: {
        default: "h-11 px-5",
        sm: "h-9 rounded-[16px] px-4 text-xs",
        lg: "h-12 px-6"
      }
    },
    defaultVariants: {
      variant: "default",
      size: "default"
    }
  }
);

export interface ButtonProps
  extends React.ButtonHTMLAttributes<HTMLButtonElement>,
    VariantProps<typeof buttonVariants> {
  asChild?: boolean;
}

const Button = React.forwardRef<HTMLButtonElement, ButtonProps>(
  ({ className, variant, size, asChild = false, ...props }, ref) => {
    const Comp = asChild ? Slot : "button";

    return (
      <Comp
        className={cn(buttonVariants({ variant, size, className }))}
        ref={ref}
        {...props}
      />
    );
  }
);

Button.displayName = "Button";

export { Button, buttonVariants };
