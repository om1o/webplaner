import type { Metadata } from "next";
import type { ReactNode } from "react";
import { Manrope, Space_Grotesk } from "next/font/google";

import { AppShell } from "@/components/layout/app-shell";

import "./globals.css";

const sans = Manrope({
  subsets: ["latin"],
  variable: "--font-manrope"
});

const display = Space_Grotesk({
  subsets: ["latin"],
  variable: "--font-space-grotesk"
});

export const metadata: Metadata = {
  title: "WebPlan AI Omni-Assistant",
  description:
    "Agentic operating system for orchestrating commands, cloned voices, and real-world workflows."
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="en" suppressHydrationWarning>
      <body className={`${sans.variable} ${display.variable}`}>
        <AppShell>{children}</AppShell>
      </body>
    </html>
  );
}
