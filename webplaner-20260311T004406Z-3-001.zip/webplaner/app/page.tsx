import { OmniDashboard } from "@/components/dashboard/omni-dashboard";

export default function Home() {
  return <OmniDashboard />;
}
